-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 16, 2025 at 07:23 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `AdminID` int(11) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`AdminID`, `Email`, `Password`) VALUES
(1, 'umer12@gmail.com', 'umer_123');

-- --------------------------------------------------------

--
-- Table structure for table `disasterzones`
--

CREATE TABLE `disasterzones` (
  `ZoneID` int(11) NOT NULL,
  `DisasterName` varchar(255) NOT NULL,
  `Description` text DEFAULT NULL,
  `Location` varchar(255) NOT NULL,
  `LastUpdated` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `disasterzones`
--

INSERT INTO `disasterzones` (`ZoneID`, `DisasterName`, `Description`, `Location`, `LastUpdated`) VALUES
(1, 'Flood', 'Devastating Floods Cause Widespread Destruction and Displacement', 'Area near seaview,karachi', '2025-01-14 22:45:14'),
(2, 'Storm', 'Destructive Snowstorm Strikes, Leaving Communities in Need of Shelter and First Aid!', 'Zayarat ,Quetta', '2025-01-15 11:24:49'),
(3, 'Flood', 'Heavy rainfall caused massive flooding, displacing families and destroying infrastructure.', 'Swat Valley, Khyber Pakhtunkhwa', '2025-01-16 08:25:17'),
(4, 'Earthquake', 'A devastating earthquake struck, causing widespread destruction.', 'Muzaffarabad, Azad Kashmir', '2025-01-16 08:25:17'),
(5, 'Drought', 'Severe drought has impacted water supplies and agriculture.', 'Tharparkar, Sindh', '2025-01-16 08:25:17'),
(6, 'Landslide', 'Massive landslides have buried homes and blocked roads.', 'Murree, Punjab', '2025-01-16 08:25:17'),
(7, 'Cyclone', 'A powerful cyclone caused destruction along the coastline.', 'Gwadar, Balochistan', '2025-01-16 08:25:17'),
(8, 'Fire', 'A large fire broke out in a residential area.', 'Saddar, Karachi', '2025-01-16 08:25:17');

-- --------------------------------------------------------

--
-- Table structure for table `donations`
--

CREATE TABLE `donations` (
  `DonationID` int(11) NOT NULL,
  `DonorName` varchar(100) DEFAULT NULL,
  `AccountNO` varchar(255) DEFAULT NULL,
  `Amount` decimal(10,2) NOT NULL,
  `DonationDate` date DEFAULT curdate()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `donations`
--

INSERT INTO `donations` (`DonationID`, `DonorName`, `AccountNO`, `Amount`, `DonationDate`) VALUES
(1, 'bilal', '4220134565473', 1000.00, '2025-01-15'),
(2, 'Ashir Rao', '4220145278123', 2000.00, '2025-01-15'),
(3, 'sami ullah', '4220345678654', 10000.00, '2025-01-15'),
(6, 'hashir KAMI', '1223245345434', 1233.00, '2025-01-16');

-- --------------------------------------------------------

--
-- Table structure for table `resources`
--

CREATE TABLE `resources` (
  `ResourceID` int(11) NOT NULL,
  `ResourceType` varchar(100) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `Location` varchar(255) DEFAULT NULL,
  `LastUpdated` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `resources`
--

INSERT INTO `resources` (`ResourceID`, `ResourceType`, `Quantity`, `Location`, `LastUpdated`) VALUES
(1, 'cloths', 100, 'warehouse 1', '2025-01-15 11:33:58'),
(2, 'Blankets', 300, 'warehouse 1', '2025-01-15 11:32:07');

-- --------------------------------------------------------

--
-- Table structure for table `victims`
--

CREATE TABLE `victims` (
  `VictimID` int(11) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Age` int(11) DEFAULT NULL,
  `Gender` enum('Male','Female','Other') DEFAULT NULL,
  `Location` varchar(255) NOT NULL,
  `Needs` text DEFAULT NULL,
  `ContactInfo` varchar(50) DEFAULT NULL,
  `ZoneID` int(11) NOT NULL,
  `LastUpdated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `victims`
--

INSERT INTO `victims` (`VictimID`, `Name`, `Age`, `Gender`, `Location`, `Needs`, `ContactInfo`, `ZoneID`, `LastUpdated`) VALUES
(1, 'Bilal Ahmed', 20, 'Male', 'defence Phase VIII', 'shelter', '03243455432', 1, '2025-01-14 23:19:38'),
(2, 'Rehan Khan', 45, 'Male', 'Defence Phase 7', 'shelter', '04445367896', 1, '2025-01-15 11:20:33'),
(3, 'Saad ahmed', 56, 'Male', 'Quaid-e-Azam Residency. ', 'shelter and food required', '02315436721', 2, '2025-01-15 11:29:47'),
(4, 'Ahmed Khan', 32, 'Male', 'Swat Valley, Khyber Pakhtunkhwa', 'Shelter and clean water', '03012345678', 2, '2025-01-16 08:35:01'),
(5, 'Fatima Bibi', 28, 'Female', 'Swat Valley, Khyber Pakhtunkhwa', 'Food and medical aid', '03022345678', 2, '2025-01-16 08:35:01'),
(6, 'Abdullah Ali', 40, 'Male', 'Swat Valley, Khyber Pakhtunkhwa', 'Clothing and blankets', '03032345678', 2, '2025-01-16 08:35:01'),
(7, 'Ayesha Malik', 35, 'Female', 'Muzaffarabad, Azad Kashmir', 'Medical aid and shelter', '03042345678', 3, '2025-01-16 08:35:01'),
(8, 'Bilal Ahmed', 45, 'Male', 'Muzaffarabad, Azad Kashmir', 'Food and clean water', '03052345678', 3, '2025-01-16 08:35:01'),
(9, 'Hassan Raza', 50, 'Male', 'Muzaffarabad, Azad Kashmir', 'Temporary shelter', '03062345678', 3, '2025-01-16 08:35:01'),
(10, 'Zainab Fatima', 22, 'Female', 'Tharparkar, Sindh', 'Water and food supplies', '03072345678', 4, '2025-01-16 08:35:01'),
(11, 'Ibrahim Khan', 30, 'Male', 'Tharparkar, Sindh', 'Water and livestock feed', '03082345678', 4, '2025-01-16 08:35:01'),
(12, 'Maryam Shah', 27, 'Female', 'Tharparkar, Sindh', 'Health services', '03092345678', 4, '2025-01-16 08:35:01'),
(13, 'Muhammad Usman', 33, 'Male', 'Murree, Punjab', 'Shelter and food supplies', '03102345678', 5, '2025-01-16 08:35:01'),
(14, 'Rabia Noor', 29, 'Female', 'Murree, Punjab', 'Medical aid', '03112345678', 5, '2025-01-16 08:35:01'),
(15, 'Sana Ali', 35, 'Female', 'Murree, Punjab', 'Emergency rescue', '03122345678', 5, '2025-01-16 08:35:01'),
(16, 'Hamza Tariq', 26, 'Male', 'Gwadar, Balochistan', 'Food and clean water', '03132345678', 6, '2025-01-16 08:35:01'),
(17, 'Alina Farooq', 20, 'Female', 'Gwadar, Balochistan', 'Temporary shelter', '03142345678', 6, '2025-01-16 08:35:01'),
(18, 'Rashid Khan', 39, 'Male', 'Gwadar, Balochistan', 'Clothing and health services', '03152345678', 6, '2025-01-16 08:35:01'),
(19, 'Sara Malik', 34, 'Female', 'Saddar, Karachi', 'Medical aid and shelter', '03162345678', 7, '2025-01-16 08:35:01'),
(20, 'Ali Hassan', 29, 'Male', 'Saddar, Karachi', 'Food supplies', '03172345678', 7, '2025-01-16 08:35:01'),
(21, 'Nida Javed', 22, 'Female', 'Saddar, Karachi', 'Clothing and temporary housing', '03182345678', 7, '2025-01-16 08:35:01'),
(22, 'Hina Aslam', 25, 'Female', 'Saddar, Karachi', 'Health services', '03192345678', 8, '2025-01-16 08:45:56'),
(23, 'Usman Farooq', 38, 'Male', 'Saddar, Karachi', 'Temporary housing', '03202345678', 8, '2025-01-16 08:45:56'),
(24, 'Kashif Ali', 40, 'Male', 'Saddar, Karachi', 'Food and water', '03212345678', 8, '2025-01-16 08:45:56'),
(25, 'Areeba Khan', 31, 'Female', 'Saddar, Karachi', 'Clothing', '03222345678', 8, '2025-01-16 08:45:56'),
(26, 'Junaid Akhtar', 28, 'Male', 'Saddar, Karachi', 'Shelter', '03232345678', 8, '2025-01-16 08:45:56'),
(27, 'Rabia Sheikh', 26, 'Female', 'Saddar, Karachi', 'First aid', '03242345678', 8, '2025-01-16 08:45:56'),
(28, 'Kamran Yousaf', 35, 'Male', 'Saddar, Karachi', 'Emergency funds', '03252345678', 8, '2025-01-16 08:45:56'),
(29, 'Aqsa Riaz', 29, 'Female', 'Saddar, Karachi', 'Shelter', '03262345678', 8, '2025-01-16 08:45:56'),
(30, 'Fahad Khan', 30, 'Male', 'Saddar, Karachi', 'Clean drinking water', '03272345678', 8, '2025-01-16 08:45:56'),
(31, 'Marium Shahid', 27, 'Female', 'Saddar, Karachi', 'Food supplies', '03282345678', 8, '2025-01-16 08:45:56'),
(32, 'Shahzad Ahmed', 33, 'Male', 'Saddar, Karachi', 'Temporary shelter', '03292345678', 8, '2025-01-16 08:45:56'),
(33, 'Lubna Tariq', 22, 'Female', 'Saddar, Karachi', 'Medical assistance', '03302345678', 8, '2025-01-16 08:45:56'),
(34, 'Hammad Saeed', 36, 'Male', 'Saddar, Karachi', 'Clothing', '03312345678', 8, '2025-01-16 08:45:56'),
(35, 'Sadia Faisal', 28, 'Female', 'Saddar, Karachi', 'Housing and food', '03322345678', 8, '2025-01-16 08:45:56'),
(36, 'Faraz Ali', 31, 'Male', 'Saddar, Karachi', 'Blankets and shelter', '03332345678', 8, '2025-01-16 08:45:56'),
(37, 'Zain Raza', 34, 'Male', 'Saddar, Karachi', 'Health services', '03342345678', 8, '2025-01-16 08:45:56'),
(38, 'Mehwish Javed', 30, 'Female', 'Saddar, Karachi', 'Temporary housing', '03352345678', 8, '2025-01-16 08:45:56'),
(39, 'Ali Asghar', 27, 'Male', 'Saddar, Karachi', 'Food and clothing', '03362345678', 8, '2025-01-16 08:45:56'),
(40, 'Nimra Qureshi', 24, 'Female', 'Saddar, Karachi', 'Medical aid', '03372345678', 8, '2025-01-16 08:45:56'),
(41, 'Danish Khan', 32, 'Male', 'Saddar, Karachi', 'Emergency shelter', '03382345678', 8, '2025-01-16 08:45:56'),
(42, 'asma khan', 30, 'Female', 'zero point', 'cloths', '03243455431', 2, '2025-01-16 17:59:09');

-- --------------------------------------------------------

--
-- Table structure for table `volunteerassignmentlog`
--

CREATE TABLE `volunteerassignmentlog` (
  `LogID` int(11) NOT NULL,
  `AssignmentID` int(11) NOT NULL,
  `VolunteerID` int(11) NOT NULL,
  `ZoneID` int(11) NOT NULL,
  `Action` varchar(255) DEFAULT 'Task Given',
  `Date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `volunteerassignmentlog`
--

INSERT INTO `volunteerassignmentlog` (`LogID`, `AssignmentID`, `VolunteerID`, `ZoneID`, `Action`, `Date`) VALUES
(1, 1, 1, 1, 'Task Given', '2025-01-14 22:53:42'),
(2, 1, 1, 1, 'Task Done', '2025-01-15 00:00:00'),
(9, 3, 1, 1, 'Task Given', '2025-01-16 17:26:24'),
(10, 3, 1, 1, 'Task Done', '2025-01-16 17:27:09');

-- --------------------------------------------------------

--
-- Table structure for table `volunteerassignments`
--

CREATE TABLE `volunteerassignments` (
  `AssignmentID` int(11) NOT NULL,
  `VolunteerID` int(11) NOT NULL,
  `ZoneID` int(11) NOT NULL,
  `TaskDescription` text NOT NULL,
  `AssignmentDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `volunteerassignments`
--

INSERT INTO `volunteerassignments` (`AssignmentID`, `VolunteerID`, `ZoneID`, `TaskDescription`, `AssignmentDate`) VALUES
(1, 1, 1, 'provide first aid and cpr', '2025-01-14 22:53:42'),
(2, 2, 2, 'look for people in need of shelter', '2025-01-15 11:27:32'),
(3, 1, 1, 'give first aid', '2025-01-16 17:26:24');

-- --------------------------------------------------------

--
-- Table structure for table `volunteers`
--

CREATE TABLE `volunteers` (
  `VolunteerID` int(11) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Age` int(11) NOT NULL,
  `Gender` enum('Male','Female','Other') NOT NULL,
  `CNIC` varchar(15) NOT NULL,
  `Contact` varchar(15) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Address` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `volunteers`
--

INSERT INTO `volunteers` (`VolunteerID`, `Name`, `Age`, `Gender`, `CNIC`, `Contact`, `Email`, `Password`, `Address`) VALUES
(1, 'hashir hashmi ', 20, 'Male', '4220103456543', '03332455645', 'hashir12@gmail.com', 'hashir321', 'Ithehaad Banglows, Nipa'),
(2, 'sabih asad', 21, 'Male', '4210145643256', '03352269657', 'sabihasad1@gmail.com', 'sabih123', 'house no.A-8 B-5,karachi');

-- --------------------------------------------------------

--
-- Table structure for table `volunteer_skills`
--

CREATE TABLE `volunteer_skills` (
  `SkillID` int(11) NOT NULL,
  `VolunteerID` int(11) NOT NULL,
  `Skill` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `volunteer_skills`
--

INSERT INTO `volunteer_skills` (`SkillID`, `VolunteerID`, `Skill`) VALUES
(1, 1, 'first aid'),
(2, 2, 'communication skills'),
(3, 2, 'empathy');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`AdminID`),
  ADD UNIQUE KEY `Email` (`Email`);

--
-- Indexes for table `disasterzones`
--
ALTER TABLE `disasterzones`
  ADD PRIMARY KEY (`ZoneID`);

--
-- Indexes for table `donations`
--
ALTER TABLE `donations`
  ADD PRIMARY KEY (`DonationID`);

--
-- Indexes for table `resources`
--
ALTER TABLE `resources`
  ADD PRIMARY KEY (`ResourceID`);

--
-- Indexes for table `victims`
--
ALTER TABLE `victims`
  ADD PRIMARY KEY (`VictimID`),
  ADD KEY `ZoneID` (`ZoneID`);

--
-- Indexes for table `volunteerassignmentlog`
--
ALTER TABLE `volunteerassignmentlog`
  ADD PRIMARY KEY (`LogID`),
  ADD KEY `AssignmentID` (`AssignmentID`),
  ADD KEY `VolunteerID` (`VolunteerID`),
  ADD KEY `ZoneID` (`ZoneID`);

--
-- Indexes for table `volunteerassignments`
--
ALTER TABLE `volunteerassignments`
  ADD PRIMARY KEY (`AssignmentID`),
  ADD KEY `VolunteerID` (`VolunteerID`),
  ADD KEY `ZoneID` (`ZoneID`);

--
-- Indexes for table `volunteers`
--
ALTER TABLE `volunteers`
  ADD PRIMARY KEY (`VolunteerID`),
  ADD UNIQUE KEY `CNIC` (`CNIC`),
  ADD UNIQUE KEY `Email` (`Email`);

--
-- Indexes for table `volunteer_skills`
--
ALTER TABLE `volunteer_skills`
  ADD PRIMARY KEY (`SkillID`),
  ADD KEY `VolunteerID` (`VolunteerID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `AdminID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `disasterzones`
--
ALTER TABLE `disasterzones`
  MODIFY `ZoneID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `donations`
--
ALTER TABLE `donations`
  MODIFY `DonationID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `resources`
--
ALTER TABLE `resources`
  MODIFY `ResourceID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `victims`
--
ALTER TABLE `victims`
  MODIFY `VictimID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `volunteerassignmentlog`
--
ALTER TABLE `volunteerassignmentlog`
  MODIFY `LogID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `volunteerassignments`
--
ALTER TABLE `volunteerassignments`
  MODIFY `AssignmentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `volunteers`
--
ALTER TABLE `volunteers`
  MODIFY `VolunteerID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `volunteer_skills`
--
ALTER TABLE `volunteer_skills`
  MODIFY `SkillID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `victims`
--
ALTER TABLE `victims`
  ADD CONSTRAINT `victims_ibfk_1` FOREIGN KEY (`ZoneID`) REFERENCES `disasterzones` (`ZoneID`) ON DELETE CASCADE;

--
-- Constraints for table `volunteerassignmentlog`
--
ALTER TABLE `volunteerassignmentlog`
  ADD CONSTRAINT `volunteerassignmentlog_ibfk_1` FOREIGN KEY (`AssignmentID`) REFERENCES `volunteerassignments` (`AssignmentID`) ON DELETE CASCADE,
  ADD CONSTRAINT `volunteerassignmentlog_ibfk_2` FOREIGN KEY (`VolunteerID`) REFERENCES `volunteers` (`VolunteerID`) ON DELETE CASCADE,
  ADD CONSTRAINT `volunteerassignmentlog_ibfk_3` FOREIGN KEY (`ZoneID`) REFERENCES `disasterzones` (`ZoneID`) ON DELETE CASCADE;

--
-- Constraints for table `volunteerassignments`
--
ALTER TABLE `volunteerassignments`
  ADD CONSTRAINT `volunteerassignments_ibfk_1` FOREIGN KEY (`VolunteerID`) REFERENCES `volunteers` (`VolunteerID`) ON DELETE CASCADE,
  ADD CONSTRAINT `volunteerassignments_ibfk_2` FOREIGN KEY (`ZoneID`) REFERENCES `disasterzones` (`ZoneID`) ON DELETE CASCADE;

--
-- Constraints for table `volunteer_skills`
--
ALTER TABLE `volunteer_skills`
  ADD CONSTRAINT `volunteer_skills_ibfk_1` FOREIGN KEY (`VolunteerID`) REFERENCES `volunteers` (`VolunteerID`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
